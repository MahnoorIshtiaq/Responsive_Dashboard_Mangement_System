const Orders = [
    {
        productName: 'Mini Drone',
        productNumber: '3762',
        payment: 'Due',
        Status: 'Pending'
    },
    {
        productName: 'Smartwatch',
        productNumber: '4827',
        payment: 'Completed',
        Status: 'Delivered'
    },
    {
        productName: 'Bluetooth Speaker',
        productNumber: '5943',
        payment: 'Due',
        Status: 'Declined'
    },
    {
        productName: 'Wireless Earbuds',
        productNumber: '6791',
        payment: 'Completed',
        Status: 'Delivered'
    },
    {
        productName: 'Action Camera',
        productNumber: '8032',
        payment: 'Due',
        Status: 'Pending'
    }
];
