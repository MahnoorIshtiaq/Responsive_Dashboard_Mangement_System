function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Simple validation (you can expand this as needed)
    if (username === "admin" && password === "password") {
        window.location.href = 'dashboard.html';  // Redirect to dashboard
    } else {
        alert('Invalid login credentials!');
    }
}

document.querySelector('.logout').addEventListener('click', function() {
    alert('You have logged out.');
    window.location.href = 'index.html';
});

const sideMenu = document.querySelector("aside");
const menuBtn = document.querySelector("#menu-btn");
const closeBtn = document.querySelector("#close-btn");
const themeToggler = document.querySelector(".theme-toggle");

menuBtn.addEventListener('click', () => {
    sideMenu.style.display = 'block';
    })

    closeBtn.addEventListener('click', () => {
        sideMenu.style.display = 'none';
    })

    themeToggler.addEventListener('click', () => {
        document.body.classList.toggle("dark-theme");

        themeToggler.querySelector('span:nth-child(1)').classList.toggle('active');
        themeToggler.querySelector('span:nth-child(2)').classList.toggle('active');

    })

Orders.forEach(order=> {
    const tr = document.createElement('tr');
    const trContent = `
                       <td>${order.productName}</td>
                       <td>${order.productNumber}</td>
                       <td>${order.payment}</td>
                       <td class="${order.Status === 
                        'Declined' ? 'color1' : 
                        order.Status === 'Pending' ? 'warning' 
                        :'success'}">${order.Status}</td>
                       <td class="primary">Details</td>
                       `;
    tr.innerHTML = trContent;
    document.querySelector('table tbody').appendChild(tr);
})